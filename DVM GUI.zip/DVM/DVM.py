import sys
from PyQt5.QtWidgets import*
from PyQt5 import uic

# Load UI files
Ui_FormMain = uic.loadUiType("main.ui")[0]
Ui_FormMenu = uic.loadUiType("menu.ui")[0]
Ui_FormMembership = uic.loadUiType("membership.ui")[0]
Ui_FormPayment = uic.loadUiType("payment.ui")[0]
Ui_FormCard = uic.loadUiType("card.ui")[0]
Ui_FormMoney = uic.loadUiType("money.ui")[0]
Ui_FormBye = uic.loadUiType("bye.ui")[0]

class Main(QMainWindow,QWidget,Ui_FormMain):
    
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setupUi(self)
        self.start.clicked.connect(self.btn_main_to_menu)
        self.show()
            
    def btn_main_to_menu(self):

        self.menu = Menu()
        self.menu.exec()
        self.show()
        

class Menu(QDialog,QWidget,Ui_FormMenu):
    def __init__(self):
        super(Menu,self).__init__()
        self.initUI()
        self.show()
        
    def initUI(self):
        self.setupUi(self)
        self.Membership.clicked.connect(self.membership_clicked)
        self.cider.clicked.connect(self.menu_clicked)
        self.coke.clicked.connect(self.menu_clicked)
        self.orangejuice.clicked.connect(self.menu_clicked)
        self.water.clicked.connect(self.menu_clicked)
        self.juice1.clicked.connect(self.menu_clicked)
        self.juice2.clicked.connect(self.menu_clicked)

        
    def membership_clicked(self):
        self.membership = Membership()
        self.membership.exec()
        self.show()
        
    def menu_clicked(self):
        self.payment = Payment()
        self.payment.exec()
        self.show()
               
    
class Membership(QDialog,QWidget,Ui_FormMembership):
    
    def __init__(self):
        super(Membership,self).__init__()
        self.initUI()
        self.show()
        
    def initUI(self):
        self.setupUi(self)
        self.commandLinkButton.clicked.connect(self.close)
        
    
class Payment(QDialog,QWidget,Ui_FormPayment):
    def __init__(self):
        super(Payment,self).__init__()
        self.initUI()
        self.show()
        
    def initUI(self):
        self.setupUi(self)
        self.cardpay.clicked.connect(self.card_clicked)
        self.moneypay.clicked.connect(self.money_clicked)
        self.commandLinkButton.clicked.connect(self.close)
        self.show()
        
    def card_clicked(self):
        self.cardbtn = Card()
        self.cardbtn.exec()
        self.show()
        
    def money_clicked(self):
        self.moneybtn = Money()
        self.moneybtn.exec()
        self.show()
        
    
class Card(QDialog,QWidget,Ui_FormCard):
    
    def __init__(self):
        super(Card,self).__init__()
        self.initUI()
        self.show()
        
    def initUI(self):
        self.setupUi(self)
        self.Cardbutton.clicked.connect(self.byebye)
        self.show()

    def byebye(self):
        self.close()
        self.bye = Bye()
        self.bye.exec()
        self.show()
        
class Money(QDialog,QWidget,Ui_FormMoney):
    
    def __init__(self):
        super(Money,self).__init__()
        self.initUI()
        self.show()
        
    def initUI(self):
        self.setupUi(self)
        self.Moneybutton.clicked.connect(self.byebye)
        self.show()

    def byebye(self):
        self.close()
        self.bye = Bye()
        self.bye.exec()
        self.show()
        
class Bye(QDialog, QWidget, Ui_FormBye):
    
    def __init__(self):
        super(Bye, self).__init__()
        self.initUI()
        self.show()

    def initUI(self):
        self.setupUi(self)



if __name__ == '__main__':
    app = QApplication(sys.argv)

    m = Main()
    m.show()

    sys.exit(app.exec_())
                 

